package com.example.questao6

import android.content.*
import android.os.*
import android.support.v7.app.AppCompatActivity
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity()
{
    companion object {
        const val TAG = "MainActivity"
    }

    var serviceMSG: Messenger? = null
    var limit: Boolean = false
    var countMSG = 0

    data class Node(val value: String) {
        var proximo: Node? = null
    }

    private val receiver: BroadcastReceiver = object : BroadcastReceiver()
    {
        override fun onReceive(p0: Context?, p1: Intent?)
        {

            val responseJson = p1?.getStringExtra("result")
            val node = Gson().fromJson(responseJson, Node::class.java)
            result.text = getStringList(node)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        button.isEnabled = false
        button.setOnClickListener({ processMSG() })

        connectToService()
    }

    override fun onResume()
    {
        val filter = IntentFilter()
        filter.addAction("ProcessadorMSGFinished")
        registerReceiver(receiver, filter)
        super.onResume()
    }

    override fun onStop()
    {
        unregisterReceiver(receiver)
        super.onStop()
    }

    override fun onDestroy()
    {
        unbindService(Connect)
        super.onDestroy()
    }

    fun getStringList(msg: Node?): String
    {
        var msgAux = msg
        val builder = StringBuilder()

        while (msgAux != null)
        {
            builder.append("${msgAux.value}, ")
            msgAux = msgAux.proximo
        }

        return builder.toString()
    }

    private val Connect = object : ServiceConnection {
        override fun onServiceConnected(className: ComponentName, service: IBinder) {
            serviceMSG = Messenger(service)
            limit = true
            button.isEnabled = true

            serverStatus.text = getString(R.string.server_run)
        }

        override fun onServiceDisconnected(className: ComponentName)
        {
            serviceMSG = null
            limit = false
            button.isEnabled = false

            serviceMSG.text = getString(R.string.server_off)
        }
    }

    private fun connectToService()
    {
        val intent = Intent()
        intent.`package` = "com.example.questao6"
        intent.addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES)
        intent.component = ComponentName("com.example.questao6", "com.example.questao6.ProcessadorMsg")
        bindService(intent, Connect, Context.BIND_AUTO_CREATE)
    }

    private fun processMSG()
    {
        if (limit && serviceMSG != null)
        {
            val msg = Message.obtain()
            val bundle = Bundle()

            val msg = Node("1")
            msg.proximo = Node("1")
            msg.proximo!!.proximo = Node("2")
            msg.proximo!!.proximo!!.proximo = Node("2")
            msg.proximo!!.proximo!!.proximo!!.proximo = Node("3")
            msg.proximo!!.proximo!!.proximo!!.proximo!!.proximo = Node("3")
            msg.proximo!!.proximo!!.proximo!!.proximo!!.proximo!!.proximo = Node("1")

            msg.text = "MSG inicial: " +
                    "${getStringList(msg)}"

            val emailJson = Gson().toJson(msg)

            bundle.putString("email", emailJson)

            msg.data = bundle

            try
            {
                this.serviceMSG!!.send(msg)
                countMSG++
            }
            catch (e: RemoteException)
            {
                e.printStackTrace()
            }
        }
    }
}