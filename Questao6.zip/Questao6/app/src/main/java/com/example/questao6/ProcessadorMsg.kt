package com.example.questao6

import android.annotation.SuppressLint
import android.app.Service
import android.content.Intent
import android.os.*
import android.util.Log
import com.google.gson.Gson
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors


class ProcessadorMsg : Service()
{
    companion object {
        const val TAG = "ProcessadorMsg"
    }
    private lateinit var execService: ExecutorService
    private var msg = Messenger(
                        IncomingHandler())

    data class Node(val valor: String)
    {
        var proximo: Node? = null
    }

    override fun onCreate()
    {
        execService = Executors.newSingleThreadExecutor()
        Log.i(TAG, "Service onCreate")
        super.onCreate()
    }

    override fun onDestroy()
    {
        Log.i(TAG, "Service onDestroy")
    }

    override fun onBind(intent: Intent): IBinder?
    {
        Log.i(TAG, "Service onBind, appName: " +
                "${intent.extras.getString("clientName")}")
        return msg.binder
    }

    private fun sendBroadcast(response: String)
    {
        val intent = Intent("ProcessadorFinished")
        val ext = Bundle()
        ext.putString("result", response)

        intent.putExtras(ext)
        sendBroadcast(intent)
    }

    @SuppressLint("HandlerLeak")
    internal inner class IncomingHandler : Handler()
    {
        override fun handleMessage(msg: Message)
        {
            val data = msg.data
            val dataString = data.getString("email")
            val hearNode = Gson().fromJson(dataString, Node::class.java)

            execService.submit(WorkerMsg(hearNode))
        }
    }

    internal inner class WorkerMsg(private val msg: Node) : Runnable
    {
        override fun run()
        {
            removeDuplicate(msg)

            val responseJson = Gson().toJson(msg)

            sendBroadcast(responseJson)
        }
    }

    fun removeDuplicate(head: Node?)
    {
        val hashSet = hashSetOf<String>()
        var atual = head
        var anterior: Node? = null

        while (atual != null)
        {
            val value = atual.valor

            if (hashSet.contains(value))
            {
                anterior!!.proximo = atual.proximo
            } else
              {
                hashSet.add(value)
                anterior = atual
              }
            atual = atual.proximo
        }
    }
}