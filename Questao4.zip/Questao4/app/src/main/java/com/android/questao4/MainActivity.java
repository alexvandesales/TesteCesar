package com.android.questao4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity
{
    EditText textoDigitado;
    MyArrayAdapter adaptArray;
    ArrayList<String> listaPalavras;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        textoDigitado = (EditText) findViewById(R.id.edit_text_pesquisa);

        final ListView listview = (ListView) findViewById(R.id.listview_lista);

        listaPalavras = ListaPalavras();

        adaptArray = new MyArrayAdapter(this, android.R.layout.simple_list_item_1, listaPalavras);

        listview.setAdapter(adaptArray);
    }

    public void onResetClick(View view)
    {
        final ArrayList<String> list = ListaPalavras();
        listaPalavras.clear();
        listaPalavras.addAll(list);
        adaptArray.notifyDataSetChanged();
    }

    public void onPesquisarClick(View view)
    {
        String palavra = textoDigitado.getText().toString();
        ArrayList<String> list = new ArrayList<String>();
        Utils util = new Utils();

        for (String item : listaPalavras)
        {
            boolean erroCobinacaoPalavras = util.CombinacaoPalavras(palavra, item);
            boolean erroCobinacaoLetras = util.CombinacaoLetras(palavra, item);

            if(erroCobinacaoPalavras && erroCobinacaoLetras)
            {
                continue;
            }

            if(util.CombinacaoPalavras(palavra, item) || util.CombinacaoLetras(palavra, item))
            {
                list.add(item);
            }
        }

        listaPalavras.clear();
        listaPalavras.addAll(list);
        adaptArray.notifyDataSetChanged();
    }

    private class MyArrayAdapter extends ArrayAdapter<String>
    {
        ArrayList<String> itemsListaPalavras = new ArrayList<>();

        public MyArrayAdapter(Context context, int textViewResourceId, ArrayList<String> objects)
        {
            super(context, textViewResourceId, objects);
            for (int i = 0; i < objects.size(); ++i)
            {
                itemsListaPalavras = objects;
            }
        }
    }

    private ArrayList<String> ListaPalavras()
    {
        ArrayList<String> listPesquisa = new ArrayList<String>();
        listPesquisa.add("yuo");
        listPesquisa.add("pporbalbyale");
        listPesquisa.add("nmoo");
        listPesquisa.add("mpeissngslli");
        return listPesquisa;
    }
}