package com.android.questao4;

public class Utils {

    public boolean CombinacaoLetras(String first, String second)
    {
        if(second.length() == first.length())
        {
            if(first.charAt(0) == second.charAt(0))
            {
                int tamPalavra = second.length();
                int diferencaCaracteres = 0;

                for(int i = 0; i < tamPalavra; i++)
                {
                    if(second.charAt(i) != first.charAt(i))
                    {
                        diferencaCaracteres++;
                    }
                }

                if(tamPalavra > 3)
                {
                    if(diferencaCaracteres < (tamPalavra * (2 / 3)))
                    {
                        return true;
                    } else
                      {
                        return false;
                      }
                } else
                  {
                    return (diferencaCaracteres > 0);
                  }
            } else
              {
                return false;
             }
        }
        return false;
    }

    public boolean CombinacaoPalavras(String first, String second)
    {
        int firstLength = first.length();
        int secondLength = second.length();

        if(Math.abs(firstLength - secondLength)>1)
        {
            return false;
        }

        int count = 0,
            i = 0,
            j = 0;

        while(i < firstLength && j < secondLength)
        {
            if(first.charAt(i) != second.charAt(j))
            {
                if(count == 1)
                {
                    return false;
                }
                if(firstLength > secondLength)
                {
                    i++;
                }
                else
                    if (firstLength < secondLength)
                    {
                        j++;
                    }
                    else
                    {
                        i++;
                        j++;
                    }
                    count++;
                }
            else
            {
                i++;
                j++;
             }
        }

        if(i < firstLength || j < secondLength)
        {
            count++;
        }

        return (count == 1);
    }
}
